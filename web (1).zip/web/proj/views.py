from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, redirect, get_object_or_404
from .models import Person
from .forms import PersonForm

def create_or_update(request, pk=None):
    instance = Person.objects.get(pk=pk) if pk else None
    form = PersonForm(request.POST or None, instance=instance)
    if form.is_valid():
        form.save()
        return redirect('list')

    return render(request, 'form.html', {'form': form})

def list_data(request):
    data = Person.objects.all()
    return render(request, 'list.html', {'data': data})

def update_data(request, pk):
    instance = get_object_or_404(Person, pk=pk)
    form = PersonForm(request.POST or None, instance=instance)
    if form.is_valid():
        form.save()
        return redirect('list')
    return render(request, 'update.html', {'form': form})

def delete_data(request, pk):
    instance = get_object_or_404(Person, pk=pk)
    if request.method == 'POST':
        instance.delete()
        return redirect('list')
    return render(request, 'confirm_delete.html', {'instance': instance})

def search_view(request):
    query = request.GET.get('query')  # Get the search query from the URL query parameters

    if query:
        # Perform the search using your model's filter method or any other search logic
        results = Person.objects.filter( CWS_Description__icontains=query)  # Replace 'your_field' with the actual field name in your model

    else:
        # If no query is provided, return all data (or handle it as per your requirements)
        results = Person.objects.all()

    return render(request, 'search_results.html', {'results': results, 'query': query})


