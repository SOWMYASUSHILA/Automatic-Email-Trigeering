from django.db import models

# Create your models here.
class Person(models.Model):
    CWS_Description = models.CharField(max_length=399,blank=True, null=True)
    HSI_Date_Revision_Date = models.DateField(blank=True, null=True)
    MSDS_Date_Revision_Date = models.DateField(blank=True, null=True)
    F13 = models.CharField(max_length=255, blank=True, null=True)
    Classification = models.CharField(max_length=255, blank=True,null=True)
    Symbols = models.CharField(max_length=255, blank=True, null=True)
    Used_In = models.TextField(blank=True, null=True)
    Approved_Quantity = models.CharField(max_length=225,blank=True,null=True)
    Register_Number = models.CharField(max_length=255,blank=True, null=True)
    Responsible = models.CharField(max_length=255, blank=True, null=True)
    PH_No = models.CharField(max_length=20, blank=True, null=True)
    Send_Reminder = models.CharField(max_length=300,blank=True,null=True)

    def __str__(self):
        return str(self.CWS_Description)
    