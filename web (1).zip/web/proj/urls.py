from django.urls import path
from . import views

urlpatterns = [
    path('create/', views.create_or_update, name='create'),
    path('update/<int:pk>/', views.create_or_update, name='update'),
    path('list/', views.list_data, name='list'), 
    path('update/<int:pk>/', views.update_data, name='update'),
    path('delete/<int:pk>/', views.delete_data, name='delete'), 
    path('search/', views.search_view, name='search_view'),
]
