# import_export_data.py
import pandas as pd
from django.core.management.base import BaseCommand
from proj.models import Person
import logging

class Command(BaseCommand):
    help = 'Import or export data from Excel to the database and vice versa.'

    def add_arguments(self, parser):
        parser.add_argument('--import', action='store_true', help='Import data from Excel to the database')
        parser.add_argument('--export', action='store_true', help='Export data from the database to Excel')

    def handle(self, *args, **options):
        logger = logging.getLogger(__name__)

        if options['import']:
            # Import data from Excel to the database
            df = pd.read_excel(r"C:\Users\LENOVO\Desktop\web\proj\management\commands\Database58.xlsx")

            df['HSI_Date_Revision_Date'] = pd.to_datetime(df['HSI_Date_Revision_Date'], format='%Y-%m-%d', errors='coerce')
            


            # Remove rows with invalid date values (NaT)
            df = df.dropna(subset=['HSI_Date_Revision_Date'])

            # Convert the DataFrame to a list of dictionaries
            records = df.to_dict(orient='records')

            # Log the number of rows read from the Excel file
            logger.info(f'Read {len(records)} rows from Excel.')

            Person.objects.all().delete()

            # Log the number of rows being inserted
            logger.info(f'Inserting {len(records)} rows into the database.')

            # Use bulk_create to insert all rows
            Person.objects.bulk_create([Person(**row) for row in records])
            self.stdout.write(self.style.SUCCESS('Successfully imported the database from Excel'))

        if options['export']:
            # Export data from the database to Excel
            data = Person.objects.all().values()
            df = pd.DataFrame.from_records(data)
            df.to_excel(r"C:\Users\LENOVO\Desktop\web\proj\management\commands\Database58.xlsx", index=False)
            self.stdout.write(self.style.SUCCESS('Successfully exported the database to Excel'))