from django.contrib import admin
from .models import Person
from import_export.admin import ImportExportModelAdmin
# Register your models here.

class PersonAdmin(ImportExportModelAdmin):
    list_display=("CWS_Description","HSI_Date_Revision_Date","MSDS_Date_Revision_Date","F13","Classification","Symbols","Used_In","Approved_Quantity","Register_Number","Responsible","PH_No","Send_Reminder")


admin.site.register(Person,PersonAdmin)